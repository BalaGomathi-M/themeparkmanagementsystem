<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="userdashboard.php"><i class="fa fa-dashboard fa-fw nav_icon"></i>Dashboard</a>
                        </li>
             
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-envelope nav_icon"></i>Entry Ticket<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="create-entry-ticket.php">Add Tickets</a>
                                </li>
                                <li>
                                    <a href="manage-entry-tickets.php">View tickets</a>
                                </li>

                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

    <li>
                            <a href="#"><i class="fa fa-envelope nav_icon"></i>Ride Ticket<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="create-ride-tickets.php">Add Tickets</a>
                                </li>
								<li>
                                    <a href="manage-ride-tickets.php">View tickets</a>
                                </li>
                                
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

               
               
                     
              
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>