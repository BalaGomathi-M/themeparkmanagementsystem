<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="dashboard.php"><i class="fa fa-dashboard fa-fw nav_icon"></i>Dashboard</a>
                        </li>
             
                     <li>
                            <a href="#"><i class="fa fa-dollar nav_icon"></i>Pricing<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="entry-pricing.php">Entry</a>
                                </li>
                                <li>
                                    <a href="normalride-pricing.php">Normal Ride</a>
                                </li>

                                 <li>
                                    <a href="waterride-pricing.php">Water Ride</a>
                                </li>
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-envelope nav_icon"></i>Entry Ticket<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                               
                                <li>
                                    <a href="manage-entry-tickets.php">Manage Tickets</a>
                                </li>
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

    <li>
                            <a href="#"><i class="fa fa-envelope nav_icon"></i>Ride Ticket<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                                                <li>
                                    <a href="manage-ride-tickets.php">Manage Tickets</a>
                                </li>
                            
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

               
               
                     
              
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>